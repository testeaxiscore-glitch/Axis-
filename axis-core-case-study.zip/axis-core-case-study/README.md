# Axis Core — Technical Case Study

> Case técnico público de uma plataforma SaaS multi-tenant para gestão de negócios de serviços.
>
> **Este repositório não contém o código-fonte de produção.** Ele documenta arquitetura, decisões técnicas, segurança, integrações e exemplos isolados/simplificados de implementação.

## Por que este repositório existe

O Axis Core nasceu como um produto real e evoluiu de um CRUD tradicional para uma plataforma com requisitos de produção: multi-tenancy, agenda concorrente, billing, RBAC, portals públicos, IA com contexto autorizado, migrações de banco e ferramentas internas de suporte.

Criei este case para demonstrar **engenharia de software e arquitetura** sem publicar regras comerciais, credenciais, código proprietário ou detalhes sensíveis do produto.

## Stack

| Camada | Tecnologias |
|---|---|
| Frontend | React, TypeScript, Vite |
| Backend | Python, FastAPI |
| ORM / migrations | SQLAlchemy 2, Alembic |
| Banco | PostgreSQL |
| Auth | JWT access token + refresh token rotativo |
| Billing | Mercado Pago |
| IA | OpenAI Responses API / GPT-5.6 Luna |
| Deploy | Render |
| Testes | Pytest + validações TypeScript |

## Visão geral da arquitetura

```mermaid
flowchart LR
    U[Usuário] --> FE[React / Vite]
    C[Cliente final] --> PB[Booking público]

    FE --> API[FastAPI]
    PB --> API

    API --> AUTH[Auth + RBAC]
    API --> DB[(PostgreSQL)]
    API --> BILL[Mercado Pago]
    API --> AICTX[AI Context Builder]
    AICTX --> OAI[OpenAI / GPT-5.6 Luna]

    SUP[Support Console] --> API

    subgraph Tenant Boundary
      AUTH
      API
      AICTX
    end
```

## Principais desafios de engenharia

### 1. Multi-tenancy e autorização

A aplicação trabalha com `Organization` + `Membership`, separando dados por organização e diferenciando perfis administrativos e profissionais. A regra de tenant é aplicada no backend, e não apenas escondida na interface.

**Objetivo:** impedir leitura ou mutação acidental de dados entre empresas.

Leia: [docs/multi-tenancy.md](docs/multi-tenancy.md)

### 2. Integridade de agenda sob concorrência

Checar disponibilidade apenas na aplicação não é suficiente: duas requisições podem passar pela checagem ao mesmo tempo. Por isso a agenda possui uma segunda barreira no PostgreSQL usando uma `EXCLUDE CONSTRAINT` com range temporal.

**Resultado:** conflitos são evitados inclusive em condições de corrida.

Leia: [docs/architecture.md](docs/architecture.md) e [examples/appointment_conflict.sql](examples/appointment_conflict.sql)

### 3. Billing idempotente

Pagamentos assíncronos exigem assumir que webhooks podem ser reenviados, chegar fora de ordem ou ser processados mais de uma vez. O fluxo de billing utiliza identificadores do provedor e processamento idempotente para não duplicar efeitos financeiros ou períodos de assinatura.

Leia: [docs/billing.md](docs/billing.md)

### 4. IA sem acesso direto ao banco

A IA não recebe conexão com o banco nem liberdade para gerar SQL. O Axis primeiro aplica tenant + RBAC, calcula um snapshot autorizado e minimizado e só então envia esse contexto ao modelo.

**Princípio:** o LLM trabalha sobre um contexto preparado pela aplicação, nunca sobre a fonte de dados bruta.

Leia: [docs/ai-integration.md](docs/ai-integration.md)

### 5. Ferramentas internas de operação

Além do produto, foi criada uma Central de Suporte para diagnóstico e reparos seguros: saúde da aplicação, assinaturas, pagamentos, usuários, profissionais, agenda, logs e integrações.

Isso reduz a necessidade de “entrar no banco e corrigir na mão”.

![Central de Suporte Axis](docs/screenshots/support-console.png)

Leia: [docs/observability-and-support.md](docs/observability-and-support.md)

## Fluxo de uma requisição autenticada

```mermaid
sequenceDiagram
    participant B as Browser
    participant A as FastAPI
    participant R as RBAC / Tenant Guard
    participant D as PostgreSQL

    B->>A: Request + access token
    A->>R: valida usuário, organização e papel
    R-->>A: contexto autorizado
    A->>D: query com organization_id + escopo
    D-->>A: dados do tenant
    A-->>B: resposta
```

## Decisões arquiteturais documentadas

- [ADR-001 — PostgreSQL como banco de produção](docs/decisions/ADR-001-postgresql.md)
- [ADR-002 — Integridade atômica da agenda](docs/decisions/ADR-002-atomic-scheduling.md)
- [ADR-003 — IA baseada em snapshot autorizado](docs/decisions/ADR-003-ai-authorized-snapshot.md)
- [ADR-004 — Webhooks idempotentes](docs/decisions/ADR-004-idempotent-webhooks.md)

## Segurança

Alguns controles relevantes implementados no produto:

- isolamento multi-tenant no backend;
- RBAC entre administrador e profissional;
- refresh token rotativo em cookie HttpOnly;
- validação de `Origin` para operações sensíveis de cookie;
- convites de profissionais de uso único, com hash e expiração;
- configuração de produção com fail-fast para JWT/CORS/cookies/banco inseguros;
- tokens de portal com escopo limitado;
- preços de planos resolvidos no servidor;
- minimização de PII antes de chamadas à IA;
- proteção atômica contra double booking no PostgreSQL.

Leia: [docs/security.md](docs/security.md)

## Exemplos de código

A pasta [`examples/`](examples/) contém exemplos **didáticos e propositalmente simplificados** de alguns padrões utilizados no projeto:

- escopo de tenant e RBAC;
- constraint de concorrência da agenda;
- processamento idempotente de webhook;
- construção de contexto seguro para IA.

Eles não são cópias do código de produção.

## O que este case demonstra

- desenho de APIs REST com FastAPI;
- modelagem e migrations com SQLAlchemy/Alembic;
- PostgreSQL e constraints de integridade;
- autenticação, autorização e multi-tenancy;
- integração com APIs externas;
- idempotência e processamento assíncrono de eventos;
- integração de IA com controle de contexto e privacidade;
- React/TypeScript para aplicação administrativa;
- preocupação com observabilidade, suporte e operação em produção;
- evolução arquitetural guiada por riscos reais do produto.

## O que não está neste repositório

Por decisão de segurança e propriedade intelectual, este repositório **não publica**:

- código-fonte completo do frontend/backend;
- secrets, tokens ou variáveis de produção;
- regras comerciais internas;
- dados reais de clientes;
- URLs administrativas privadas;
- prompts internos completos;
- implementações completas de billing ou suporte.

## Estrutura

```text
axis-core-case-study/
├── README.md
├── NOTICE.md
├── SECURITY.md
├── docs/
│   ├── architecture.md
│   ├── multi-tenancy.md
│   ├── security.md
│   ├── billing.md
│   ├── ai-integration.md
│   ├── observability-and-support.md
│   ├── interview-notes.md
│   ├── screenshots/
│   └── decisions/
└── examples/
    ├── README.md
    ├── tenant_scope.py
    ├── appointment_conflict.sql
    ├── idempotent_webhook.py
    └── ai_context_builder.py
```

## Status

Case técnico em evolução. A plataforma real permanece em repositório privado.

---

**Autor:** Kayki Molina  
**Objetivo do case:** demonstrar experiência prática em desenvolvimento backend/full-stack e arquitetura de aplicações SaaS.
