"""Simplified portfolio example — not production source."""
from dataclasses import dataclass
from enum import StrEnum


class Role(StrEnum):
    ADMIN = "ADMIN"
    PROFESSIONAL = "PROFESSIONAL"


@dataclass(frozen=True)
class RequestScope:
    user_id: int
    organization_id: int
    role: Role
    professional_id: int | None = None


class Forbidden(Exception):
    pass


def resolve_scope(*, user_id: int, organization_id: int, membership_repo) -> RequestScope:
    membership = membership_repo.find(user_id=user_id, organization_id=organization_id)
    if membership is None or not membership.active:
        raise Forbidden("User does not belong to this organization")

    professional_id = None
    if membership.role == Role.PROFESSIONAL:
        profile = membership_repo.professional_profile(membership.id)
        if profile is None or not profile.active:
            raise Forbidden("Professional profile is unavailable")
        professional_id = profile.id

    return RequestScope(
        user_id=user_id,
        organization_id=organization_id,
        role=membership.role,
        professional_id=professional_id,
    )


def list_appointments(scope: RequestScope, appointment_repo):
    """The tenant filter is mandatory; role can further reduce the scope."""
    filters = {"organization_id": scope.organization_id}

    if scope.role == Role.PROFESSIONAL:
        filters["professional_id"] = scope.professional_id

    return appointment_repo.list(**filters)
