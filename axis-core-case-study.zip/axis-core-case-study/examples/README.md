# Exemplos

Os arquivos desta pasta são **exemplos simplificados escritos para o case público**.

Eles ilustram padrões arquiteturais do projeto sem reproduzir o código proprietário em produção.

- `tenant_scope.py`: tenant + RBAC antes de acessar um recurso;
- `appointment_conflict.sql`: defesa atômica contra sobreposição de agenda;
- `idempotent_webhook.py`: processamento idempotente de evento externo;
- `ai_context_builder.py`: criação de snapshot mínimo para IA.
