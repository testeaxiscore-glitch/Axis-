"""Simplified portfolio example — not production source."""
from dataclasses import dataclass


@dataclass(frozen=True)
class AIContext:
    organization: dict
    metrics: dict
    customers_at_risk: list[dict]


def build_ai_context(*, scope, question: str, analytics) -> AIContext:
    """Build context after authorization; never let the model query the DB."""
    metrics = analytics.summary(
        organization_id=scope.organization_id,
        professional_id=scope.professional_id,
    )

    # Administrative financial fields are removed from professional scope.
    if scope.role == "PROFESSIONAL":
        metrics.pop("organization_revenue", None)
        metrics.pop("team_ranking", None)

    customers_at_risk: list[dict] = []
    if any(term in question.lower() for term in ("cliente", "retorno", "reativar")):
        rows = analytics.customers_at_risk(organization_id=scope.organization_id)
        customers_at_risk = [
            {
                "first_name": row.first_name,
                "days_since_last_visit": row.days_since_last_visit,
            }
            for row in rows
        ]

    # No phone, email, document IDs, addresses or free-form notes are included.
    return AIContext(
        organization={"id": scope.organization_id},
        metrics=metrics,
        customers_at_risk=customers_at_risk,
    )
