-- Simplified portfolio example — not production schema.
-- PostgreSQL can be the final authority against concurrent double booking.

CREATE EXTENSION IF NOT EXISTS btree_gist;

ALTER TABLE appointments
ADD CONSTRAINT no_overlapping_active_appointments
EXCLUDE USING gist (
    organization_id WITH =,
    professional_id WITH =,
    tstzrange(start_at, end_at, '[)') WITH &&
)
WHERE (status IN ('SCHEDULED', 'CONFIRMED', 'IN_PROGRESS'));

-- The API still checks availability first for a friendly error message.
-- This constraint protects the race between two concurrent transactions.
