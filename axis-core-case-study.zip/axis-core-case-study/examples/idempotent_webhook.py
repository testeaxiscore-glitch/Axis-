"""Simplified portfolio example — not production source."""


def process_payment(payment_id: str, *, provider, payments, subscriptions, uow):
    # Never trust the webhook body as the payment authority.
    remote = provider.get_payment(payment_id)

    if remote.status != "approved":
        return {"status": "ignored"}

    with uow.transaction():
        local = payments.lock_by_provider_id(payment_id)

        # Replay-safe: the effect was already applied.
        if local is not None and local.applied_at is not None:
            return {"status": "already_processed"}

        charge = payments.require_expected_charge(remote.external_reference)
        if remote.amount_cents != charge.expected_amount_cents:
            raise ValueError("Unexpected payment amount")

        if local is None:
            local = payments.create_from_provider(remote)

        subscriptions.apply_paid_period(
            organization_id=charge.organization_id,
            plan=charge.plan,
            paid_at=remote.approved_at,
        )

        local.mark_applied()

    return {"status": "processed"}
