# Integração de IA

## Objetivo

Permitir que o usuário pergunte sobre a operação em linguagem natural sem entregar ao modelo acesso irrestrito ao banco de dados.

## Arquitetura

```mermaid
flowchart LR
    Q[Pergunta] --> AUTH[Auth + tenant + RBAC]
    AUTH --> DATA[Queries/analytics da aplicação]
    DATA --> MIN[Minimização de contexto]
    MIN --> SNAP[Snapshot autorizado]
    SNAP --> LLM[GPT-5.6 Luna]
    LLM --> ANSWER[Resposta]
```

## O modelo não gera SQL

O LLM não recebe credenciais de banco e não escolhe queries. O backend é responsável por decidir quais métricas e registros o usuário tem permissão para usar como contexto.

Isso evita transformar prompt injection em acesso de dados.

## Minimização

Por padrão, o contexto analítico evita dados pessoais desnecessários. Campos administrativos também podem ser removidos quando o papel do usuário não permite visualizá-los.

## Contexto conversacional

A interface mantém uma janela curta de histórico para controlar custo e tamanho do contexto. O texto da conversa não precisa ser armazenado para medir consumo: métricas técnicas de tokens podem ser registradas separadamente.

## Fallback

Uma camada de fallback determinístico permite que algumas respostas operacionais continuem disponíveis em caso de indisponibilidade do provedor de IA.

Veja [`../examples/ai_context_builder.py`](../examples/ai_context_builder.py).
