# Observabilidade e Central de Suporte

Um SaaS não termina quando a feature funciona no happy path. Em produção, também é necessário entender rapidamente **por que um cliente não consegue operar**.

Por isso o Axis possui uma Central de Suporte restrita ao desenvolvedor.

## Diagnósticos

Entre os sinais monitorados pelo console interno:

- saúde do banco;
- status de integrações;
- assinaturas bloqueadas;
- pagamentos pendentes antigos;
- erros técnicos recentes;
- uso/fallback da IA;
- perfis profissionais inconsistentes;
- possíveis duplicidades;
- atendimentos presos em estados intermediários.

## Reparos seguros

O objetivo é evitar SQL manual em produção. Ações administrativas passam por endpoints específicos, com validação e auditoria.

Exemplos conceituais:

- revogar sessões;
- reconstruir perfil profissional;
- estender trial por decisão de suporte;
- corrigir status com motivo obrigatório;
- conciliar pagamento com o provedor;
- transferir agendamentos futuros validando conflito.

## Auditoria

Ações de suporte registram contexto técnico como:

```text
action + actor + organization + before + after + reason + timestamp
```

Sem armazenar secrets ou corpos sensíveis desnecessários.

![Central de Suporte](screenshots/support-console.png)
