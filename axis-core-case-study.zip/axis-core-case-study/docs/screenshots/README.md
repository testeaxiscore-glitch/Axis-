# Screenshots

As imagens deste diretório usam ambiente sem dados reais de clientes. Elas servem apenas para contextualizar o case técnico.
