# Arquitetura

## Contexto

O Axis Core é uma plataforma SaaS para operações de serviços com agenda, clientes, profissionais, financeiro, booking público, billing e uma camada de IA.

A arquitetura foi mantida como um **modular monolith**: uma API FastAPI com módulos bem definidos compartilhando um banco PostgreSQL. Para o estágio atual do produto, isso reduz complexidade operacional sem impedir separação de responsabilidades.

## Componentes

```mermaid
flowchart TB
    subgraph Clients
      WEB[App React]
      BOOK[Booking público]
      CP[Portal do cliente]
      PP[Portal do profissional]
    end

    subgraph Backend[FastAPI backend]
      AUTH[Auth / Sessions]
      TENANT[Tenant + RBAC]
      SCHED[Scheduling]
      CRM[Clients / Services]
      FIN[Finance]
      BILL[Billing]
      AI[AI orchestration]
      SUPPORT[Support operations]
    end

    DB[(PostgreSQL)]
    MP[Mercado Pago]
    OAI[OpenAI]

    WEB --> AUTH
    BOOK --> SCHED
    CP --> SCHED
    PP --> TENANT

    AUTH --> TENANT
    TENANT --> SCHED
    TENANT --> CRM
    TENANT --> FIN
    TENANT --> BILL
    TENANT --> AI

    SCHED --> DB
    CRM --> DB
    FIN --> DB
    BILL --> DB
    AI --> DB
    SUPPORT --> DB

    BILL --> MP
    AI --> OAI
```

## Por que modular monolith

Microservices adicionariam custos de observabilidade, deploy, consistência distribuída e infraestrutura antes de existir uma necessidade clara de escalabilidade independente por domínio.

No estágio atual, a prioridade é:

1. fronteiras de domínio claras;
2. regras críticas protegidas no banco;
3. integrações encapsuladas em services;
4. migrations reproduzíveis;
5. testes automatizados;
6. capacidade de extrair serviços no futuro se a carga justificar.

## Requisições multi-tenant

Toda operação autenticada parte de um usuário e uma organização. O backend valida a membership e produz um contexto de autorização.

```mermaid
flowchart LR
    TOKEN[JWT] --> USER[User]
    USER --> MEMBERSHIP[Membership]
    MEMBERSHIP --> ORG[Organization]
    MEMBERSHIP --> ROLE{Role}
    ROLE -->|ADMIN| GLOBAL[Escopo do tenant]
    ROLE -->|PROFESSIONAL| OWN[Escopo profissional]
```

## Agenda e concorrência

A disponibilidade é checada na aplicação para gerar mensagens amigáveis, mas a integridade final pertence ao banco.

```text
App check -> INSERT/UPDATE -> PostgreSQL exclusion constraint -> commit
```

Se duas requisições concorrentes tentarem ocupar o mesmo intervalo, apenas uma pode persistir.

## Deploy

Frontend e backend são deployados separadamente. O backend executa migrations antes de subir a nova versão.

```mermaid
flowchart LR
    GIT[Git repository] --> BUILD[Build]
    BUILD --> MIG[Alembic upgrade head]
    MIG --> API[FastAPI service]
    API --> PG[(PostgreSQL)]
    BUILD --> FE[Vite static site]
```
