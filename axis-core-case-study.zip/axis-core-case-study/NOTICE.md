# Notice

Este repositório é um **case técnico de portfólio**.

Os exemplos foram reescritos e simplificados para fins educacionais e de demonstração. Eles não representam o código-fonte completo do produto Axis Core e não devem ser considerados uma distribuição do software comercial.

Nomes, diagramas, regras e exemplos podem omitir detalhes deliberadamente para proteger segurança, propriedade intelectual e operação do produto.
